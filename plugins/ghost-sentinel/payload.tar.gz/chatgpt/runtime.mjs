import { mkdir, open, writeFile, rename, lstat, rm } from 'node:fs/promises'
import { join, resolve, isAbsolute } from 'node:path'
import { homedir } from 'node:os'
import { randomBytes, randomUUID } from 'node:crypto'
import { constants } from 'node:fs'
import { setTimeout as delay } from 'node:timers/promises'

async function readPrivateConfig(path) {
  const info = await lstat(path)
  if (!info.isFile() || info.size > 16384 || (info.mode & 0o077) || typeof process.getuid === 'function' && info.uid !== process.getuid()) throw new Error('private configuration required')
  const file = await open(path, 'r')
  let value
  try { const buffer = Buffer.alloc(16385); const result = await file.read(buffer, 0, buffer.length, 0); if (result.bytesRead > 16384) throw new Error('private configuration over limit'); value = JSON.parse(buffer.subarray(0, result.bytesRead)) } finally { await file.close() }
  if (value.format !== 1 || !/^[a-f0-9]{64}$/.test(value.token ?? '') || typeof value.installationId !== 'string' || !value.installationId || typeof value.pluginId !== 'string' || !value.pluginId || !['dataDir', 'coreDataDir', 'sessionsRoot', 'metadataSocket'].every(key => typeof value[key] === 'string' && isAbsolute(value[key]))) throw new Error('invalid installation configuration')
  if (value.port !== undefined && (!Number.isSafeInteger(value.port) || value.port < 1 || value.port > 65535)) throw new Error('invalid installation port')
  if (value.notificationBundlePath !== undefined && (typeof value.notificationBundlePath !== 'string' || !isAbsolute(value.notificationBundlePath) || !value.notificationBundlePath.endsWith('.app'))) throw new Error('invalid notification bundle configuration')
  if (value.releaseId !== undefined && !/^[a-f0-9]{64}$/.test(value.releaseId)) throw new Error('invalid installation release identity')
  if (value.initialEnrollmentBaseline !== undefined) {
    const baseline = value.initialEnrollmentBaseline
    if (!baseline || Object.keys(baseline).length !== 2 || typeof baseline.claimable !== 'boolean' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(baseline.id ?? '')) throw new Error('invalid initial enrollment baseline configuration')
  }
  return value
}

export { readPrivateConfig as loadInstallationConfig }

export async function prepareInstallation({ dataDir, coreDataDir, sessionsRoot = join(homedir(), '.codex/sessions'), metadataSocket = join(homedir(), '.codex/app-server-control/app-server-control.sock'), pluginId, notificationBundlePath, releaseId } = {}) {
  if (typeof dataDir !== 'string' || typeof coreDataDir !== 'string' || !isAbsolute(dataDir) || !isAbsolute(coreDataDir) || !isAbsolute(sessionsRoot) || !isAbsolute(metadataSocket) || typeof pluginId !== 'string' || !pluginId.trim()) throw new Error('explicit installation paths and plugin identity required')
  if (notificationBundlePath !== undefined && (typeof notificationBundlePath !== 'string' || !isAbsolute(notificationBundlePath) || !notificationBundlePath.endsWith('.app'))) throw new Error('explicit notification bundle path required')
  if (releaseId !== undefined && !/^[a-f0-9]{64}$/.test(releaseId)) throw new Error('explicit release identity required')
  if (notificationBundlePath !== undefined) notificationBundlePath = resolve(notificationBundlePath)
  dataDir = resolve(dataDir)
  await mkdir(dataDir, { recursive: true, mode: 0o700 })
  const info = await lstat(dataDir)
  if (!info.isDirectory() || info.mode & 0o077) throw new Error('private installation directory required')
  const configPath = join(dataDir, 'installation.json'), pluginDir = join(dataDir, 'plugin')
  try {
    const file = await open(configPath, 'wx', 0o600)
    try { await file.writeFile(JSON.stringify({ format: 1, installationId: randomUUID(), initialEnrollmentBaseline: { id: randomUUID(), claimable: true }, dataDir, coreDataDir: resolve(coreDataDir), sessionsRoot: resolve(sessionsRoot), metadataSocket, pluginId, ...(notificationBundlePath === undefined ? {} : { notificationBundlePath }), ...(releaseId === undefined ? {} : { releaseId }), token: randomBytes(32).toString('hex') }) + '\n') } finally { await file.close() }
  } catch (error) { if (error.code !== 'EEXIST') throw error }
  const saved = await readPrivateConfig(configPath)
  if (['dataDir', 'coreDataDir', 'sessionsRoot', 'metadataSocket', 'pluginId'].some(key => saved[key] !== ({ dataDir, coreDataDir: resolve(coreDataDir), sessionsRoot: resolve(sessionsRoot), metadataSocket, pluginId })[key])) throw new Error('installation configuration already exists with different settings')
  if (notificationBundlePath !== undefined && saved.notificationBundlePath !== notificationBundlePath) throw new Error('installation configuration already exists with different settings')
  if (releaseId !== undefined && saved.releaseId !== releaseId) throw new Error('installation configuration already exists with different settings')
  await mkdir(join(pluginDir, '.codex-plugin'), { recursive: true, mode: 0o700 })
  return { configPath, pluginDir }
}

export const HELPER_PROTOCOL = 'ghost-sentinel-chatgpt-helper/1'
export const HELPER_VERSION = '0.1.0-dev.1'

const uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/
async function maintenance(config) {
  const path = join(config.dataDir, 'maintenance.json'), unconfirmed = 'installation-maintenance-unconfirmed'
  const identity = info => JSON.stringify([info.dev, info.ino, info.size, info.mtimeMs, info.ctimeMs, info.uid, info.mode])
  let file, before
  try { before = await lstat(path) } catch (error) { return error.code === 'ENOENT' ? null : unconfirmed }
  if (!before.isFile() || before.size > 1024 || (before.mode & 0o7777) !== 0o600 || typeof process.getuid === 'function' && before.uid !== process.getuid()) return unconfirmed
  try {
    file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW)
    const opened = await file.stat(), bytes = Buffer.alloc(1025), read = await file.read(bytes, 0, bytes.length, 0)
    const [after, current] = await Promise.all([file.stat(), lstat(path)])
    if (read.bytesRead > 1024 || read.bytesRead !== opened.size || [opened, after, current].some(info => identity(info) !== identity(before))) return unconfirmed
    const value = JSON.parse(bytes.subarray(0, read.bytesRead))
    return value && Object.keys(value).length === 3 && value.format === 1 && value.installationId === config.installationId && uuid.test(value.operationId) ? 'installation-maintenance' : unconfirmed
  } catch { return unconfirmed }
  finally { await file?.close().catch(() => {}) }
}

async function writePrivateJson(path, value) {
  const temporary = path + '.' + randomUUID() + '.tmp'
  try { await writeFile(temporary, JSON.stringify(value, null, 2) + '\n', { mode: 0o600, flag: 'wx' }); await rename(temporary, path) }
  finally { await rm(temporary, { force: true }) }
}
async function record(path) {
  try {
    const info = await lstat(path)
    if (!info.isFile() || info.size > 16384 || info.mode & 0o077 || typeof process.getuid === 'function' && info.uid !== process.getuid()) throw new Error('untrusted helper record')
    const file = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW)
    try { const buffer = Buffer.alloc(16385), value = await file.read(buffer, 0, buffer.length, 0); if (value.bytesRead > 16384) throw new Error('helper record over limit'); return JSON.parse(buffer.subarray(0, value.bytesRead)) }
    finally { await file.close() }
  } catch (error) { if (error.code === 'ENOENT') return null; throw error }
}
const ownIdentity = (value, config) => value?.protocol === HELPER_PROTOCOL && value.installationId === config.installationId && value.version === HELPER_VERSION && (config.releaseId === undefined || value.releaseId === config.releaseId) && Number.isSafeInteger(value.pid) && value.pid > 0 && typeof value.runId === 'string' && /^[a-f0-9-]{36}$/.test(value.runId)
const identityMatches = (a, b) => ['protocol', 'installationId', 'version', 'pid', 'runId', 'ownership', 'releaseId'].every(key => a[key] === b[key])
const portOf = url => { const parsed = new URL(url); if (parsed.protocol !== 'http:' || parsed.hostname !== '127.0.0.1' || parsed.username || parsed.password || parsed.pathname !== '/' || parsed.search || parsed.hash || !parsed.port) throw new Error('untrusted helper endpoint'); return Number(parsed.port) }
async function stablePort(config) {
  const connection = await record(join(config.dataDir, 'plugin/.mcp.json'))
  if (!connection) return config.port ?? 0
  const entry = connection.mcpServers?.sentinel
  if (Object.keys(connection.mcpServers ?? {}).length !== 1 || entry?.http_headers?.Authorization !== 'Bearer ' + config.token) throw new Error('untrusted helper endpoint')
  const port = portOf(entry.url.replace(/\/mcp$/, '/'))
  if (entry.url !== `http://127.0.0.1:${port}/mcp` || config.port !== undefined && config.port !== port) throw new Error('helper endpoint differs from installation')
  return port
}
async function existing(config, owner, port, ownership) {
  if (!ownIdentity(owner, config)) throw new Error('untrusted helper owner')
  if ((owner.ownership ?? 'helper') !== ownership) throw new Error('existing observation has different process ownership')
  const runtime = await record(join(config.dataDir, 'runtime.json'))
  if (runtime) {
    if (!ownIdentity(runtime, config) || !identityMatches(runtime, owner)) throw new Error('untrusted helper endpoint')
    const recordedPort = portOf(runtime.url)
    if (port && recordedPort !== port) throw new Error('untrusted helper endpoint')
  }
  try { process.kill(owner.pid, 0) } catch (error) { if (error.code === 'ESRCH') return { dead: true }; throw new Error('helper owner cannot be verified') }
  if (!runtime) return null
  async function unavailable() {
    const [currentOwner, currentRuntime] = await Promise.all([record(join(config.dataDir, 'runtime.lock/owner.json')), record(join(config.dataDir, 'runtime.json'))])
    if (!currentOwner || !currentRuntime) return null
    if (!identityMatches(currentOwner, owner) || !identityMatches(currentRuntime, runtime) || currentRuntime.url !== runtime.url) throw new Error('untrusted helper endpoint')
    try { process.kill(owner.pid, 0) } catch (error) { if (error.code === 'ESRCH') return { dead: true }; throw new Error('helper owner cannot be verified') }
    throw Object.assign(new Error('live helper endpoint cannot be verified'), { code: 'plugin_owner_health_unavailable' })
  }
  let response
  try { response = await fetch(runtime.url + '/health', { headers: { authorization: 'Bearer ' + config.token }, redirect: 'error', signal: AbortSignal.timeout(750) }) }
  catch { return unavailable() }
  if (response.status !== 200) throw new Error('live helper endpoint identity mismatch')
  let body
  try { body = await response.text() }
  catch { return unavailable() }
  if (!identityMatches(JSON.parse(body), owner)) throw new Error('live helper endpoint identity mismatch')
  return runtime
}

export async function resolvePluginOwner({ configPath } = {}) {
  if (typeof configPath !== 'string' || !isAbsolute(configPath)) throw new Error('explicit private configuration path required')
  const config = await readPrivateConfig(configPath), info = await lstat(config.dataDir)
  if (!info.isDirectory() || info.mode & 0o077 || typeof process.getuid === 'function' && info.uid !== process.getuid()) throw new Error('private installation directory required')
  const owner = await record(join(config.dataDir, 'runtime.lock/owner.json'))
  if (!owner) return null
  const runtime = await existing(config, owner, config.port ?? 0, 'plugin')
  return runtime && !runtime.dead ? { ...runtime, token: config.token } : null
}

export async function startFromInstallation({ configPath, pollMs = 1500, native, notificationIO, ownership = 'helper', displayName, expectedReleaseId } = {}) {
  if (typeof configPath !== 'string' || !isAbsolute(configPath)) throw new Error('explicit private configuration path required')
  if (!['helper', 'plugin'].includes(ownership)) throw new Error('invalid observation ownership')
  const config = await readPrivateConfig(configPath), pluginDir = join(config.dataDir, 'plugin')
  if (expectedReleaseId !== undefined && (!/^[a-f0-9]{64}$/.test(expectedReleaseId) || config.releaseId !== expectedReleaseId)) throw Object.assign(new Error('installation release differs from executable'), { code: 'plugin_release_mismatch' })
  const info = await lstat(config.dataDir)
  if (!info.isDirectory() || info.mode & 0o077 || typeof process.getuid === 'function' && info.uid !== process.getuid()) throw new Error('private installation directory required')
  const lock = join(config.dataDir, 'runtime.lock'), port = ownership === 'plugin' ? config.port ?? 0 : await stablePort(config), runId = randomUUID()
  const identity = { protocol: HELPER_PROTOCOL, installationId: config.installationId, runId, pid: process.pid, version: HELPER_VERSION, ...(ownership === 'plugin' ? { ownership } : {}), ...(config.releaseId === undefined ? {} : { releaseId: config.releaseId }) }
  const deadline = Date.now() + 2500
  while (true) {
    try { await mkdir(lock, { mode: 0o700 }); break }
    catch (error) { if (error.code !== 'EEXIST') throw error }
    const owner = await record(join(lock, 'owner.json'))
    if (owner) {
      const live = await existing(config, owner, port, ownership)
      if (live?.dead) {
        const current = await record(join(lock, 'owner.json'))
        if (current && identityMatches(current, owner)) { await rm(join(config.dataDir, 'runtime.json'), { force: true }); await rm(lock, { recursive: true, force: true }) }
        continue
      }
      if (live) return { ...live, reused: true, pluginDir, refresh: async () => {}, diagnostics: () => ({ reused: true }), close: async () => {} }
    }
    if (Date.now() >= deadline) throw new Error('helper owner startup or endpoint cannot be verified')
    await delay(25)
  }
  let adapter, core, retentionProfileSignature, closing = null, revoking = null, publicationPending = null, stopping = false, retentionTimer = null, retentionPending = null, retentionSignature = null, retentionNextAt = null, retentionError = null
  let stopReason = 'requested', qualificationRevoked = false, readyResolve, closedResolve, closedReject
  const ready = new Promise(resolve => { readyResolve = resolve })
  const closed = new Promise((resolve, reject) => { closedResolve = resolve; closedReject = reject })
  closed.catch(() => {})
  function retentionObserved(value, error) {
    if (stopping) return
    const next = value?.retention ? value.retention.nextExpiryAt : value?.nextExpiryAt, generatedAt = value?.generatedAt
    if (error || !Number.isSafeInteger(generatedAt) || next !== null && (!Number.isSafeInteger(next) || next <= generatedAt)) {
      retentionError = error?.code ?? 'retention_deadline_unconfirmed'; retentionNextAt = Date.now() + 60000
    } else { retentionError = null; retentionNextAt = next === null ? null : Date.now() + next - generatedAt }
    scheduleRetention()
  }
  function scheduleRetention() {
    clearTimeout(retentionTimer); retentionTimer = null
    if (stopping) return
    const delay = retentionNextAt === null ? 60000 : Math.max(1000, Math.min(60000, retentionNextAt - Date.now()))
    retentionTimer = setTimeout(() => { retentionTimer = null; void maintainRetention() }, delay)
    retentionTimer.unref()
  }
  function maintainRetention(force = false) {
    if (stopping) return Promise.resolve()
    if (retentionPending) return retentionPending
    retentionPending = (async () => {
      try {
        adapter?.diagnostics()
        const signature = await retentionProfileSignature(config.coreDataDir)
        if (stopping) return
        if (!signature) { retentionSignature = null; retentionNextAt = null; retentionError = null; return }
        if (!force && signature === retentionSignature && (retentionNextAt === null || retentionNextAt > Date.now())) return
        const result = await core.maintenance()
        if (stopping) return
        retentionSignature = await retentionProfileSignature(config.coreDataDir)
        if (result) retentionObserved(result)
      } catch (error) { retentionError = error.code ?? 'retention_maintenance_unavailable'; retentionNextAt = Date.now() + 60000 }
    })().finally(() => { retentionPending = null; scheduleRetention() })
    return retentionPending
  }
  const revokePublication = () => revoking ??= (async () => {
    // Startup retains write errors; withdrawal must still check partial publication.
    await publicationPending?.catch(() => {})
    const owner = await record(join(lock, 'owner.json'))
    if (owner && identityMatches(owner, identity)) {
      const value = await record(join(config.dataDir, 'runtime.json'))
      if (value && identityMatches(value, identity)) await rm(join(config.dataDir, 'runtime.json'), { force: true })
    }
  })()
  const close = () => closing ??= (async () => {
    stopping = true; clearTimeout(retentionTimer); retentionTimer = null
    const failures = []
    const attempt = async run => { try { await run() } catch (error) { for (const failure of error instanceof AggregateError ? error.errors : [error]) if (!failures.includes(failure)) failures.push(failure) } }
    await attempt(revokePublication)
    const stopped = adapter?.close(); stopped?.catch(() => {})
    if (ownership !== 'plugin') await attempt(() => core?.cancelPending())
    await attempt(() => retentionPending)
    await attempt(() => stopped)
    await attempt(() => core?.close())
    await attempt(async () => {
      const owner = await record(join(lock, 'owner.json'))
      if (owner && identityMatches(owner, identity)) {
        const value = await record(join(config.dataDir, 'runtime.json'))
        if (value && identityMatches(value, identity)) await rm(join(config.dataDir, 'runtime.json'), { force: true })
        await rm(lock, { recursive: true, force: true })
      }
    })
    if (failures.length) throw failures.length === 1 ? failures[0] : new AggregateError(failures, 'Observation cleanup failed')
  })().then(() => { const result = { reason: stopReason }; closedResolve(result); return result }, error => { closedReject(error); throw error })
  try {
    await writePrivateJson(join(lock, 'owner.json'), identity)
    const [coreIO, { createNativeIO }, { startChatGPTAdapter }, { createNativeNotificationIO }] = await Promise.all([
      import('./lazy-core.mjs'), import('./native-io.mjs'), import('./adapter.mjs'), import('./native-notifications.mjs'),
    ])
    retentionProfileSignature = coreIO.retentionProfileSignature
    core = coreIO.createLazyCore({ dataDir: config.coreDataDir, onRetention: retentionObserved })
    await maintainRetention(true)
    const rawHostIO = native ?? createNativeIO({ pluginId: config.pluginId, socketPath: config.metadataSocket })
    const hostIO = { ...rawHostIO, async sampleHost() {
      const reason = await maintenance(config)
      if (reason) return { available: false, reason }
      if (config.releaseId !== undefined) {
        try { if ((await readPrivateConfig(configPath)).releaseId !== config.releaseId) return { available: false, reason: 'plugin-release-superseded' } }
        catch { return { available: false, reason: 'plugin-release-unconfirmed' } }
      }
      return rawHostIO.sampleHost()
    } }
    const initialEnrollmentBaseline = config.initialEnrollmentBaseline ? { id: config.initialEnrollmentBaseline.id, initialize: config.initialEnrollmentBaseline.claimable } : undefined
    if (initialEnrollmentBaseline?.initialize) {
      // Consume locally before any source registration; crashes never reissue it.
      config.initialEnrollmentBaseline = { id: initialEnrollmentBaseline.id, claimable: false }
      await writePrivateJson(configPath, config)
    }
    const notifier = notificationIO ?? (config.notificationBundlePath ? createNativeNotificationIO({ bundlePath: config.notificationBundlePath, installationId: config.installationId }) : undefined)
    const onQualificationLost = ownership === 'plugin' ? reason => { qualificationRevoked = true; stopReason = reason; const revoked = revokePublication(); void ready.then(close).catch(() => {}); return revoked } : undefined
    adapter = await startChatGPTAdapter({ core, native: hostIO, notificationIO: notifier, sessionsRoot: config.sessionsRoot, dataDir: config.dataDir, installationId: config.installationId, token: config.token, port, pollMs, displayName, collectMaterials: true, nativeOriginVersion: 2, initialEnrollmentBaseline, runtimeStatus: () => { if (ownership === 'plugin' && (qualificationRevoked || stopping)) throw new Error('plugin observation is stopping'); return { ...identity } }, onQualificationLost })
    if (qualificationRevoked || adapter.diagnostics().closed) throw Object.assign(new Error('plugin startup qualification was revoked'), { code: 'plugin_startup_qualification_revoked' })
    const selectedPort = portOf(adapter.url)
    if (port && selectedPort !== port) throw new Error('helper changed its configured endpoint')
    if (config.port === undefined) await writePrivateJson(configPath, { ...config, port: selectedPort })
    if (ownership === 'helper') {
      await mkdir(join(pluginDir, '.codex-plugin'), { recursive: true, mode: 0o700 })
      await writePrivateJson(join(pluginDir, '.codex-plugin/plugin.json'), { name: 'ghost-sentinel', version: HELPER_VERSION, description: 'ChatGPT.app 本机主会话只读检查', mcpServers: './.mcp.json', interface: { displayName: 'Sentinel 会话检查', shortDescription: '本机主会话 · 只读检查' } })
      await writePrivateJson(join(pluginDir, '.mcp.json'), { mcpServers: { sentinel: { url: adapter.url + '/mcp', http_headers: { Authorization: 'Bearer ' + config.token } } } })
    }
    const value = { format: 1, ...identity, url: adapter.url, startedAt: Date.now() }
    if (stopping || qualificationRevoked) throw Object.assign(new Error('plugin startup qualification was revoked'), { code: 'plugin_startup_qualification_revoked' })
    publicationPending = writePrivateJson(join(config.dataDir, 'runtime.json'), value)
    await publicationPending
    if (stopping || qualificationRevoked) throw Object.assign(new Error('plugin startup qualification was revoked'), { code: 'plugin_startup_qualification_revoked' })
    readyResolve()
    return { ...value, reused: false, pluginDir, refresh: adapter.refresh, maintainRetention, diagnostics: () => ({ ...adapter.diagnostics(), retention: { timers: retentionTimer ? 1 : 0, pending: retentionPending ? 1 : 0, nextAt: retentionNextAt, errorCode: retentionError } }), closed, close }
  } catch (error) {
    readyResolve()
    try { await close() } catch (cleanup) {
      const failure = new AggregateError([error, cleanup], 'Observation startup failed and cleanup was incomplete', { cause: error })
      if (error?.code !== undefined) failure.code = error.code
      throw failure
    }
    throw error
  }
}
