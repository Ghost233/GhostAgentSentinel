import { createServer } from 'node:http'
import { createHash, timingSafeEqual } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js'
import { registerAppResource, registerAppTool, RESOURCE_MIME_TYPE } from '@modelcontextprotocol/ext-apps/server'
import { z } from 'zod'

export async function createPanelMCPServer({ read, control, modelSettings, installationNotifications, requestNotifications, dismissNotifications, notificationRecords, forwardTool, resources, displayName = 'Sentinel' }) {
  if (!['Sentinel', 'GhostSentinel', 'GhostSentinel test'].includes(displayName)) throw new Error('invalid panel display name')
  const title = displayName === 'GhostSentinel test' ? 'GhostSentinel 会话检查 test' : displayName + ' 会话检查'
  const html = (resources?.html ?? await readFile(new URL('./panel.html', import.meta.url), 'utf8')).replace('<title>Sentinel 会话检查</title>', '<title>' + title + '</title>').replace('<h1>Sentinel · 当前会话</h1>', '<h1>' + displayName + ' · 当前会话</h1>')
  const settingsTitle = displayName === 'GhostSentinel test' ? 'GhostSentinel 安装设置 test' : displayName + ' 安装设置'
  const settingsHtml = modelSettings || forwardTool ? (resources?.settingsHtml ?? await readFile(new URL('./settings.html', import.meta.url), 'utf8')).replace('<title>Sentinel 安装设置</title>', '<title>' + settingsTitle + '</title>').replace('<h1>Sentinel · 安装设置</h1>', '<h1>' + settingsTitle + '</h1>') : null
  const mcp = new McpServer({ name: 'ghost-sentinel-chatgpt', version: '0.1.0-dev.1' })
  const registerTool = (server, name, options, handler) => registerAppTool(server, name, options, forwardTool ? (selection, extra) => forwardTool(name, selection, extra) : handler)
  // The host can retain HTML by resource URI across plugin upgrades.
  const digest = createHash('sha256').update(html).digest('hex')
  const uri = `ui://ghost-sentinel/current-chat-${digest}.html`
  registerAppResource(mcp, 'sentinel-current-chat', uri, {}, async () => ({ contents: [{ uri, mimeType: RESOURCE_MIME_TYPE, text: html }] }))
  registerTool(mcp, 'sentinel_current_chat', {
    title, description: '只读查看当前本机主会话及24小时内已监控执行的检查结果。',
    inputSchema: { executionKey: z.string().min(1).max(256).optional(), historyCursor: z.string().min(1).max(256).optional(), expectedThreadId: z.string().min(1).max(128).optional() },
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true },
    _meta: { ui: { resourceUri: uri, visibility: ['app'] }, 'openai/ui': { entrypoints: [{ type: 'thread' }] } },
  }, async (selection, extra) => {
    const view = await read(extra._meta, selection)
    return { content: [{ type: 'text', text: view.summary }], structuredContent: view }
  })
  if (modelSettings || forwardTool) {
    const settingsUri = 'ui://ghost-sentinel/settings.html'
    registerAppResource(mcp, 'sentinel-settings', settingsUri, {}, async () => ({ contents: [{ uri: settingsUri, mimeType: RESOURCE_MIME_TYPE, text: settingsHtml }] }))
    const model = z.object({ baseUrl: z.string().min(1).max(2000), model: z.string().min(1).max(2000) }).strict()
    registerTool(mcp, 'sentinel_model_settings', {
      title: settingsTitle, description: '打开独立安装设置，读取本安装的总结模型和 JEV 配置，不依赖当前聊天采集。', inputSchema: {},
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { resourceUri: settingsUri, visibility: ['app'] }, 'openai/ui': { entrypoints: [{ type: 'global' }] } },
    }, async () => ({ content: [{ type: 'text', text: '本安装模型设置' }], structuredContent: await modelSettings.read() }))
    registerTool(mcp, 'sentinel_save_model_settings', {
      title: '保存本安装模型设置', description: '按读取的配置版本保存，仅影响本安装的分析。',
      inputSchema: { revision: z.string().min(1).max(2000), config: z.object({ llm: model.optional(), jev: model.optional() }).strict() },
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: false }, _meta: { ui: { visibility: ['app'] } },
    }, async change => {
      try { return { content: [{ type: 'text', text: '模型设置已保存' }], structuredContent: await modelSettings.save(change) } }
      catch (error) {
        const failure = error?.coreRequestFailure
        const rejected = !(error instanceof AggregateError) && !Array.isArray(error?.errors) && !Array.isArray(error?.causes)
          && error?.code !== 'analysis_config_unconfirmed' && failure?.operation === '/v1/analysis/installations/config'
          && failure.kind === 'http' && failure.status >= 400 && failure.status <= 599
        return { isError: true, content: [{ type: 'text', text: String(error?.message ?? error) }], structuredContent: { saveOutcome: rejected ? 'rejected' : 'unknown' } }
      }
    })
    if (forwardTool || typeof modelSettings?.saveScheduling === 'function') registerTool(mcp, 'sentinel_save_analysis_scheduling', {
      title: '保存查询与摘要队列设置', description: '设置本安装的会话查询并发数、查询间隔和 LLM 并发数，不更改模型配置。',
      inputSchema: z.object({ concurrency: z.number().int().min(1).max(16).optional(), queryConcurrency: z.number().int().min(1).max(16).optional(), queryIntervalMs: z.number().int().min(250).max(3600000).optional() }).strict().refine(value => Object.keys(value).length > 0),
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async change => {
      try { return { content: [{ type: 'text', text: '分析并行数已保存' }], structuredContent: await modelSettings.saveScheduling(change) } }
      catch (error) {
        const failure = error?.coreRequestFailure;
        const rejected = error?.code === 'core_feature_unsupported' || failure?.operation === '/v1/analysis/installations/scheduling' && failure.kind === 'http' && failure.status >= 400 && failure.status <= 599;
        return { isError: true, content: [{ type: 'text', text: String(error?.message ?? error) }], structuredContent: { saveOutcome: rejected ? 'rejected' : 'unknown' } }
      }
    })
    if (forwardTool || typeof modelSettings?.directory === 'function') registerTool(mcp, 'sentinel_model_directory', {
      title: '读取本机模型列表', description: '仅检查服务在线及模型名称，不调用生成或 JEV 推理。', inputSchema: { baseUrl: z.string().min(1).max(2000) },
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async (selection, extra) => ({ content: [{ type: 'text', text: '模型目录与在线状态' }], structuredContent: await modelSettings.directory(selection, { signal: extra.signal }) }))
    if (forwardTool || typeof modelSettings?.diagnostics === 'function') registerTool(mcp, 'sentinel_installation_diagnostics', {
      title: '本安装连接诊断', description: '只读核对本安装采集与保留分析状态，不读取聊天或运行模型检查。', inputSchema: z.object({}).strict(),
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async (_selection, extra) => ({ content: [{ type: 'text', text: '本安装连接诊断' }], structuredContent: await modelSettings.diagnostics({ signal: extra.signal }) }))
  }
  if (installationNotifications || forwardTool) {
    if (forwardTool || typeof installationNotifications?.records === 'function') registerTool(mcp, 'sentinel_installation_notification_records', {
      title: '本安装通知记录', description: '有界读取本安装全部已监控聊天的通知事实，不产生新投递。', inputSchema: z.object({ cursor: z.string().min(1).max(2000).optional() }).strict(),
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async (selection, extra) => ({ content: [{ type: 'text', text: '本安装通知记录' }], structuredContent: await installationNotifications.records(selection, { signal: extra.signal }) }))
    registerTool(mcp, 'sentinel_installation_notification_preferences', {
      title: '读取本安装通知偏好', description: '读取任务告警和监控故障投递偏好，系统许可另行表达。', inputSchema: z.object({}).strict(),
      annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async (_selection, extra) => ({ content: [{ type: 'text', text: '本安装通知偏好' }], structuredContent: await installationNotifications.read({ signal: extra.signal }) }))
    registerTool(mcp, 'sentinel_set_installation_notification_preference', {
      title: '保存本安装通知偏好', description: '仅改变本安装对应类别的桌面通知，不暂停采集或分析。', inputSchema: { kind: z.enum(['task-alert', 'monitoring-failure']), enabled: z.boolean() },
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async (change, extra) => {
      try { return { content: [{ type: 'text', text: '通知偏好已保存' }], structuredContent: await installationNotifications.save(change, { signal: extra.signal }) } }
      catch (error) {
        const failure = error?.coreRequestFailure
        const unsupported = error?.code === 'core_feature_unsupported' && error.coreCapabilityFailure?.operation === '/v1/notifications/installations/preferences'
        const rejected = !(error instanceof AggregateError) && !Array.isArray(error?.errors) && !Array.isArray(error?.causes)
          && (unsupported || error?.code !== 'analysis_config_unconfirmed' && failure?.operation === '/v1/notifications/installations/preferences'
            && failure.kind === 'http' && failure.status >= 400 && failure.status <= 599)
        return { isError: true, content: [{ type: 'text', text: String(error?.message ?? error) }], structuredContent: { saveOutcome: rejected ? 'rejected' : 'unknown' } }
      }
    })
    if (forwardTool || typeof installationNotifications?.requestPermission === 'function') registerTool(mcp, 'sentinel_request_installation_notification_permission', {
      title: '允许本安装桌面通知', description: '由明确用户动作请求系统许可，不依赖当前聊天。', inputSchema: z.object({}).strict(),
      annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
    }, async (_selection, extra) => ({ content: [{ type: 'text', text: '本安装系统通知许可' }], structuredContent: await installationNotifications.requestPermission({ signal: extra.signal }) }))
  }
  if (forwardTool || typeof control === 'function') registerTool(mcp, 'sentinel_set_chat_analysis', {
    title: '设置本聊天分析', description: '仅暂停或恢复当前聊天的监控分析，继续只读采集。',
    inputSchema: { paused: z.boolean(), expectedThreadId: z.string().min(1).max(128), revision: z.string().min(1).max(2000) },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: true },
    _meta: { ui: { visibility: ['app'] } },
  }, async (change, extra) => {
    const view = await control(extra._meta, change)
    return { content: [{ type: 'text', text: view.summary }], structuredContent: view }
  })
  if (forwardTool || typeof requestNotifications === 'function') registerTool(mcp, 'sentinel_request_notification_permission', {
    title: '允许桌面通知', description: '在当前聊天身份核实后请求 GhostSentinel 自己的系统通知许可。',
    inputSchema: { expectedThreadId: z.string().min(1).max(128) },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
  }, async (change, extra) => {
    const view = await requestNotifications(extra._meta, change)
    return { content: [{ type: 'text', text: view.summary }], structuredContent: view }
  })
  if (forwardTool || typeof dismissNotifications === 'function') registerTool(mcp, 'sentinel_dismiss_chat_notifications', {
    title: '关闭当前聊天已显示的提醒', description: '核实当前聊天后撤下进入时已经显示的系统通知，保留故障记录和后续新提醒。',
    inputSchema: { expectedThreadId: z.string().min(1).max(128) },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
  }, async (change, extra) => ({ content: [{ type: 'text', text: '当前聊天提醒已处理' }], structuredContent: await dismissNotifications(extra._meta, change) }))
  if (forwardTool || typeof notificationRecords === 'function') registerTool(mcp, 'sentinel_notification_records', {
    title: '本聊天通知记录', description: '只读核对当前聊天及所选执行的系统通知事实。',
    inputSchema: { expectedThreadId: z.string().min(1).max(128), executionKey: z.string().min(1).max(256).optional(), beforeSequence: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER).optional() },
    annotations: { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true }, _meta: { ui: { visibility: ['app'] } },
  }, async (selection, extra) => {
    const result = await notificationRecords(extra._meta, selection)
    return { content: [{ type: 'text', text: '本聊天通知记录' }], structuredContent: result }
  })
  return mcp
}

export async function startPanelServer({ read, control, modelSettings, installationNotifications, requestNotifications, dismissNotifications, notificationRecords, runtimeStatus, displayName = 'Sentinel', token, port = 0 }) {
  if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token)) throw new Error('installation authentication is required')
  if (!['Sentinel', 'GhostSentinel', 'GhostSentinel test'].includes(displayName)) throw new Error('invalid panel display name')
  const resources = { html: await readFile(new URL('./panel.html', import.meta.url), 'utf8'), settingsHtml: modelSettings ? await readFile(new URL('./settings.html', import.meta.url), 'utf8') : null }
  const sockets = new Set(), cleanups = new Set()
  let closed = false, activeRequests = 0, transports = 0
  const server = createServer(async (req, res) => {
    const host = '127.0.0.1:' + server.address().port
    const credential = req.headers.authorization ?? ''
    const expected = Buffer.from('Bearer ' + token), credentialBytes = Buffer.from(credential)
    if (req.headers.host !== host || credentialBytes.length !== expected.length || !timingSafeEqual(credentialBytes, expected)) return res.writeHead(401, { 'content-type': 'application/json' }).end('{"error":"Unauthorized"}')
    if (req.headers.origin && !['https://chatgpt.com', 'https://chat.openai.com'].includes(req.headers.origin)) return res.writeHead(403, { 'content-type': 'application/json' }).end('{"error":"Origin rejected"}')
    if (req.method === 'GET' && req.url === '/health' && typeof runtimeStatus === 'function') {
      try {
        const { installationId, runId, pid, version, ownership, releaseId } = await runtimeStatus()
        if ([installationId, runId, version].some(value => typeof value !== 'string' || !value || value.length > 256) || !Number.isSafeInteger(pid) || pid < 1) throw new Error('invalid helper identity')
        if (ownership !== undefined && ownership !== 'plugin') throw new Error('invalid observation ownership')
        if (releaseId !== undefined && (typeof releaseId !== 'string' || !/^[a-f0-9]{64}$/.test(releaseId))) throw new Error('invalid release identity')
        return res.writeHead(200, { 'content-type': 'application/json' }).end(JSON.stringify({ protocol: 'ghost-sentinel-chatgpt-helper/1', installationId, runId, pid, version, ...(ownership ? { ownership } : {}), ...(releaseId ? { releaseId } : {}) }))
      } catch { return res.writeHead(503, { 'content-type': 'application/json' }).end('{"error":"Helper status unavailable"}') }
    }
    if (req.url !== '/mcp') return res.writeHead(404, { 'content-type': 'application/json' }).end('{"error":"Not found"}')
    if (closed) return res.writeHead(503).end()
    activeRequests++
    const mcp = await createPanelMCPServer({ read, control, modelSettings, installationNotifications, requestNotifications, dismissNotifications, notificationRecords, displayName, resources })
    const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true })
    transports++
    let done = false
    const cleanup = async () => { if (done) return; done = true; cleanups.delete(cleanup); try { await transport.close(); await mcp.close() } finally { activeRequests--; transports-- } }
    cleanups.add(cleanup); res.once('close', () => { void cleanup() })
    try { await mcp.connect(transport); await transport.handleRequest(req, res) }
    catch { if (!res.headersSent) res.writeHead(500, { 'content-type': 'application/json' }).end('{"error":"Panel request failed"}'); else res.end() }
    finally { if (res.writableEnded) await cleanup() }
  })
  server.requestTimeout = 10000
  server.on('connection', socket => { sockets.add(socket); socket.on('close', () => sockets.delete(socket)) })
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(port, '127.0.0.1', resolve) })
  return { url: 'http://127.0.0.1:' + server.address().port, diagnostics: () => ({ activeRequests, transports, sockets: sockets.size }), async close() { if (closed) return; closed = true; for (const socket of sockets) socket.destroy(); await Promise.allSettled([...cleanups].map(close => close())); await new Promise(resolve => server.close(resolve)) } }
}
